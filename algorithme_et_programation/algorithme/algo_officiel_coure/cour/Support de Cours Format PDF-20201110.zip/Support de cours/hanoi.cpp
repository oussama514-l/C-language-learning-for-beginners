#include <stdio.h>
#include <stdlib.h>
void hanoi(int n, int s, int d){
	if(n>1){
	

		int i=6-s-d;
		
		hanoi(n-1,s,i);
		hanoi(1,s,d);
		hanoi(n-1,i,d);
	}
	else 	printf("%d   ---->  %d\n",s,d);
	

}
int main(){
	int n;
	printf("donner le nombre de disques ? "); 
	scanf("%d", &n);
	
	hanoi(n,1,3);
	
	return 0;
}
